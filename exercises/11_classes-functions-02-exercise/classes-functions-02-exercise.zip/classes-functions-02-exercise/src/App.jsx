import { Toggle } from './components/Toggle'

function App() {
    return (
        <Toggle />
    )
}

export default App
