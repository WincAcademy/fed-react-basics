import './App.css';
import { portfolioItems } from './utils/data';

export const App = () => {
    console.log(portfolioItems); // Check console to see how portfolioItems look like. You can delete this after.

    return (
        <>
        </>
    );
};