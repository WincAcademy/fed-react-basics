export const sunnyWeather = {
    imageSrc: '/weather-icons/sunny.png',
    imageAlt: 'Sunny weather icon',
    weatherType: 'Sunny',
};