import { RecipeListPage } from './pages/RecipeListPage';

export const App = () => {
    // Your state code here
    return <RecipeListPage />;
};