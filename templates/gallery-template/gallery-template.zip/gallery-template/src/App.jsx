import { portfolioItems } from './utils/data';

export const App = () => {
    // Check console to see how portfolioItems look like.
    // You can delete this after.
    console.log(portfolioItems);

    return (
        <>
        </>
    );
};